<?php
    $name ="Ferdi Endahas";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portofolio Ferdi Endahas Ahmad</title>
    <link rel="stylesheet" href="Porto.css">
</head>
<body>
    <div class="navbar">
        <nav>
                <ul class="l-navbar">
                    <li>
                        <a class="i-navbar" href="#">About Me </a>
                        <li/>
                        <li>
                            <a class="i-navbar" href="T2.html">My CV </a>
                        </li>
                        <li>
                            <a class="i-navbar" href="">More </a>
                        </li>
                    </li>
                </ul>
        </nav>
    </div>
    <div class="foto-section">
         <img class="foto" src="Foto Ferdi.JPG">
        <nav class="about">
            <h2>Tentang Saya</h2>
            <p>Nama saya adalah saya seorang profesional dengan latar belakang di bidang marketing, finance, dan data science. Saat ini, saya melakukan testnet jaringan di web3.</p>
        </nav> 
    </div>
    
    
    <section id="skills">
        <h2>Hobi</h2>
        <ul>
            <li>Membaca</li>
            <li>Berjualan</li>
            <li>Ngobrol</li>
        </ul>
    </section>
    
    <section id="contact">
        <h2>Kontak</h2>
        <p>Email: <a href="mailto:ferdi.email@example.com">ferdiendahas@gmail.com</a></p>
        <p>LinkedIn: <a href="#">linkedin.com/in/ferdi</a></p>
    </section>
</body>
</html>
